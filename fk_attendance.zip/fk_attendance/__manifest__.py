{
    "name": "AMS",
    "author": "Farook College",
    "license": "LGPL-3",
    "version": "17.0.1.0",
    
    "data": [
        "security/ir.model.access.csv",
        "views/programme.xml",
        "views/department.xml",
        "views/course.xml",
        "views/batch.xml",
        "views/faculty.xml",
        "views/student.xml",
        "views/class.xml",
        "views/timetable.xml",
        "views/tt_details.xml",
        "views/menu.xml"
        
        
    ]
}

