from odoo import api,fields, models


class Department(models.Model):
    _name = "fk.department"
    _description = "Department"

    name = fields.Char(string="Department Name", required=True)
    code = fields.Char(string="Code", required=True)
    type = fields.Selection([('aided','Aided'),('self','Self Finance')],string="Type", required=True)
