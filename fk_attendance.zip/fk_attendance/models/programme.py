from odoo import api, fields, models

class Programme(models.Model):
    _name = 'fk.programme'
    _description = 'programme'

    name = fields.Char(
        string='Title', required=True 
    )
    level = fields.Selection([('ug','UG'),('pg','PG'),('integrated pg','Integrated PG')],string='Level')
    type = fields.Selection([('aided','Aided'),('self','Self Finanace')],string='Type')
    duration = fields.Integer(string='Duration')

    department_id = fields.Many2one('fk.department', string="Department")