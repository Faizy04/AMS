from odoo import api, fields, models

class Faculty(models.Model):
    _name = 'fk.faculty'
    _description = 'Faculty'
    
    name = fields.Char(string="Name")
    code = fields.Char(string="Code")
    department_id = fields.Many2one('fk.department', string="Department")

