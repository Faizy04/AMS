from odoo import api, fields, models

class Class(models.Model):
    _name = 'fk.class'
    _description = 'class'
    _rec_name = 'division'
    
    sem = fields.Integer(string="SEM")
    level = fields.Selection([('ug','UG'),('pg','PG'),('integrated pg','Integrated PG')], string='Level')
    division = fields.Char(string="Division")
    academic_year = fields.Integer(string="Academic Year")

    course_id = fields.Many2one('fk.course', string="Course")
    student_ids = fields.Many2many('fk.student', string="Students")
    
    # Link back to Batch model
    batch_id = fields.Many2one('fk.batch', string="Batch")
    student_ids = fields.Many2many('fk.student', string="Student")
    



# from odoo import api, fields, models

# class Class(models.Model):
#     _name = 'fk.class'
#     _description = 'class'
#     _rec_name = 'division'
    
#     sem = fields.Integer(string="SEM")
#     level = fields.Selection([('ug','UG'),('pg','PG'),('integrated pg','Integrated PG')],string='Level')
#     division = fields.Char(string="Division")
#     academic_year = fields.Integer(string="Academic Year")

#     course_id = fields.Many2one('fk.course', string="Course")
#     student_ids = fields.Many2many('fk.student', string="Students")

