from odoo import api, fields, models

class Student(models.Model):
    _name = 'fk.student'
    _description = 'student'
    
    ad_no = fields.Char(string="Admission Number")
    name = fields.Char(string="Name")
    date_of_birth = fields.Date(string='DOB')
    gender = fields.Selection(
        [('male', 'Male'), ('female', 'Female')], 
        string="Gender"
    )
    tc = fields.Boolean(string='Tc Issued')
    

    batch_id = fields.Many2one('fk.batch', string="Batch")

