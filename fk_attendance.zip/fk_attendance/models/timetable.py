from odoo import api,fields, models


class Timetable(models.Model):
    _name = "fk.timetable"
    _description = "Timetable"

    academic_year = fields.Integer(string="Academic Year")
    level = fields.Selection([('ug','UG'),('pg','PG'),('integrated pg','Integrated PG')],string='Level')
    sem = fields.Integer(string="Sem")
    start_date = fields.Date(string="Start Date")
    end_date = fields.Date(string="End Date")
    locked_date = fields.Date(string="Locked Date")

    timetable_ids = fields.One2many('fk.ttdetails','id',string="Time Table")