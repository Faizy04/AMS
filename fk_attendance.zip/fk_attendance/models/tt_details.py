from odoo import api, fields, models

class TTDetails(models.Model):
    _name = 'fk.ttdetails'
    _description = 'Time Table Details'
    
    day = fields.Selection([('monday','Monday'),('tuesday','Tuesday'),('wednesday','Wednesday'),('thursday','Thursday'),('friday','Friday')],string="Day")
    hour = fields.Integer(string="Hour")
    room =  fields.Char(string="Room")
    faculty_id = fields.Many2one('fk.faculty', string="Faculty")
    class_id = fields.Many2one('fk.class', string="Class")


