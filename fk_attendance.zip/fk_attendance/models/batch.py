from odoo import api, fields, models

class Batch(models.Model):
    _name = 'fk.batch'
    _description = 'batch'
    
    name = fields.Char(compute="_compute_batch", string="Batch", store=True)
    start_year = fields.Integer(string="Start Year")
    current_sem = fields.Integer(string="Current Sem")
    is_active =  fields.Boolean(string="Is Active")
    completed = fields.Boolean(string='Completed')
    
    programme_id = fields.Many2one('fk.programme', string="Programme")

    # New field to connect Batch to Class
    class_ids = fields.One2many('fk.class', 'batch_id', string="Classes")

    @api.depends('programme_id', 'start_year')
    def _compute_batch(self):
        for rec in self:
            rec.name = f'{rec.programme_id.name}-{rec.start_year}'




# from odoo import api, fields, models

# class Batch(models.Model):
#     _name = 'fk.batch'
#     _description = 'batch'
    
#     name = fields.Char(compute="_compute_batch", string="Batch", store=True)
#     start_year = fields.Integer(string="Start Year")
#     current_sem = fields.Integer(string="Current Sem")
#     is_active =  fields.Boolean(string="Is Active")
#     completed = fields.Boolean(string='Completed')
    

#     programme_id = fields.Many2one('fk.programme', string="Programme")

#     @api.depends('programme_id', 'start_year')
#     def _compute_batch(self):
#         for rec in self:
#             rec.name = f'{rec.programme_id.name}-{rec.start_year}'
