from odoo import api, fields, models

class Course(models.Model):
    _name = 'fk.course'
    _description = 'course'
    
    name = fields.Char(string="Course")
    code = fields.Char(string="Code")
    yoa =  fields.Char(string="YOA")
    level = fields.Selection([('ug','UG'),('pg','PG'),('integrated pg','Integrated PG')],string='Level')
    sem = fields.Integer(string="Sem")

    department_id = fields.Many2one('fk.department', string="Department")

