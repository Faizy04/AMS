import json
from odoo import http
from odoo.http import request

class Snippet(http.Controller):
    @http.route('/get_total_studentscntr/apk1234', auth='public', type='http', methods=['GET'])
    def get_total_students(self):
        try:
            # Fetch students data
            students = request.env['fk.student'].sudo().search_read([], ['name', 'ad_no'])
            # Wrap the students data in a dictionary
            response_data = {
                'students': students
            }
            return request.make_response(json.dumps(response_data), headers={'Content-Type': 'application/json'})
        except Exception as e:
            return request.make_response(json.dumps({'error': str(e)}), headers={'Content-Type': 'application/json'}, status=500)


class Snippet(http.Controller):
    @http.route('/get_filtered_timetable/apk1234', auth='public', type='http', methods=['GET'])
    def get_filtered_timetable(self):
        try:
            # Fetch all timetable details
            timetable_records = request.env['fk.ttdetails'].sudo().search([])
            timetable_data = []
            
            # Track unique records to avoid duplicates
            unique_records = set()
            
            for tt in timetable_records:
                # Skip entries where class_id is not defined or is null
                if not tt.class_id or tt.class_id.id is None:
                    continue

                # Create a unique record identifier to check for duplicates
                unique_key = (tt.day, tt.hour, tt.room, tt.faculty_id.id, tt.class_id.id)

                # If this record is unique, add it to the response and mark it as seen
                if unique_key not in unique_records:
                    unique_records.add(unique_key)
                    timetable_data.append({
                        'day': tt.day,
                        'hour': tt.hour,
                        'room': tt.room,
                        'faculty': tt.faculty_id.name if tt.faculty_id else '',
                        'faculty_id': tt.faculty_id.id if tt.faculty_id else None,  # Add faculty Odoo ID
                        'class': tt.class_id.division,
                        'class_id': tt.class_id.id
                    })

            # Prepare response data
            response_data = {'timetable': timetable_data}
            return request.make_response(json.dumps(response_data), headers={'Content-Type': 'application/json'})

        except Exception as e:
            return request.make_response(json.dumps({'error': str(e)}), headers={'Content-Type': 'application/json'}, status=500)



class Snippet(http.Controller):
    @http.route('/get_students_by_class2/<int:class_id>', auth='public', type='http', methods=['GET'])
    def get_students_by_class(self, class_id):
        try:
            # Fetch the class record based on the class ID
            class_record = request.env['fk.class'].sudo().browse(class_id)

            if not class_record.exists():
                return request.make_response(
                    json.dumps({'error': 'Class not found'}),
                    headers={'Content-Type': 'application/json'},
                    status=404
                )

            students = class_record.student_ids  

            # Wrap only the students data in the response
            response_data = {
                'students': [
                    {'id': student.id, 'name': student.name, 'ad_no': student.ad_no}
                    for student in students
                ]
            }

            return request.make_response(
                json.dumps(response_data), 
                headers={'Content-Type': 'application/json'}
            )
        except Exception as e:
            return request.make_response(
                json.dumps({'error': str(e)}),
                headers={'Content-Type': 'application/json'},
                status=500
            )
        

# class Snippet(http.Controller):
#     @http.route('/get_filtered_students/<int:class_id>', auth='public', type='http', methods=['GET'])
#     def get_filtered_students(self, class_id):
#         try:
#             # Fetch students linked to the specified class ID through Batch
#             # Assuming fk.batch has a Many2one relation to fk.class
#             students = request.env['fk.class'].sudo().search_read(
#                 [('batch_id', '!=', False), ('id', '=', class_id)],  # Filter students by class_id through Batch
#                 ['student_ids.name', 'student_ids.ad_no', 'student_ids.date_of_birth', 'student_ids.gender', 'student_ids.tc']
#             )
            
#             # Convert date_of_birth to a string format
#             for student in students:
#                 if student.get('date_of_birth'):
#                     student['date_of_birth'] = student['date_of_birth'].strftime('%Y-%m-%d')  # Convert date to string

#             # Wrap the students data in a dictionary
#             response_data = {
#                 'students': students
#             }
#             return request.make_response(json.dumps(response_data), headers={'Content-Type': 'application/json'})
#         except Exception as e:
#             return request.make_response(json.dumps({'error': str(e)}), headers={'Content-Type': 'application/json'}, status=500)



# class Snippet(http.Controller):
#     @http.route('/get_students_by_class/<int:class_id>', auth='public', type='http', methods=['GET'])
#     def get_students_by_class(self, class_id):
#         try:
#             # Fetch the class record based on the class ID
#             class_record = request.env['fk.class'].sudo().browse(class_id)

#             if not class_record.exists():
#                 return request.make_response(json.dumps({'error': 'Class not found'}), headers={'Content-Type': 'application/json'}, status=404)

#             # Fetch students enrolled in the class, retrieving only id, name, and roll_no
#             students = request.env['fk.student'].sudo().search_read(
#                 [('batch_id.class_ids', 'in', [class_record.id])],
#                 ['id', 'name', 'ad_no']
#             )

#             # Wrap only the students data in the response
#             response_data = {
#                 'students': students
#             }

#             return request.make_response(json.dumps(response_data), headers={'Content-Type': 'application/json'})
#         except Exception as e:
#             return request.make_response(json.dumps({'error': str(e)}), headers={'Content-Type': 'application/json'}, status=500)
        
# student details included
# -----------------------------

# class Snippet(http.Controller):
#     @http.route('/get_timetable_with_students/apk1234', auth='public', type='http', methods=['GET'])
#     def get_timetable_with_students(self):
#         try:
#             # Fetch all timetable details
#             timetable_records = request.env['fk.ttdetails'].sudo().search([])
#             timetable_data = []

#             for tt in timetable_records:
#                 # Fetch students enrolled in the class linked to this timetable entry
#                 students = tt.class_id.student_ids
#                 student_info = [
#                     {
#                         'name': student.name,
#                         'ad_no': student.ad_no
#                     }
#                     for student in students
#                 ]
                
#                 # Add timetable details including class_id along with enrolled students
#                 timetable_data.append({
#                     'day': tt.day,
#                     'hour': tt.hour,
#                     'room': tt.room,
#                     'faculty': tt.faculty_id.name if tt.faculty_id else '',
#                     'class': tt.class_id.division if tt.class_id else '',
#                     'class_id': tt.class_id.id if tt.class_id else None,
#                     'students': student_info
#                 })
            
#             # Prepare response data
#             response_data = {'timetable': timetable_data}
#             return request.make_response(json.dumps(response_data), headers={'Content-Type': 'application/json'})

#         except Exception as e:
#             return request.make_response(json.dumps({'error': str(e)}), headers={'Content-Type': 'application/json'}, status=500)

# class Snippet(http.Controller):
#     @http.route('/get_total_facultycntr/apk1234', auth='public', type='http', methods=['GET'])
#     def get_total_faculty(self):
#         try:
#             # Fetch faculty data
#             faculty = request.env['fk.faculty'].sudo().search_read([], ['name', 'code'])
#             # Wrap the faculty data in a dictionary
#             response_data = {
#                 'faculty': faculty
#             }
#             return request.make_response(json.dumps(response_data), headers={'Content-Type': 'application/json'})
#         except Exception as e:
#             return request.make_response(json.dumps({'error': str(e)}), headers={'Content-Type': 'application/json'}, status=500)


# class Snippet(http.Controller):
#     @http.route('/get_total_studentscntrd/apk1234', auth='public', type='http', methods=['GET'])
#     def get_total_students(self):
#         try:
#             # Fetch students data, including 'dob'
#             students = request.env['fk.student'].sudo().search_read([], ['name', 'phone', 'roll_no', 'dob'])
            
#             # Format the students data, converting 'dob' to string
#             formatted_students = []
#             for student in students:
#                 student['dob'] = student['dob'].strftime('%Y-%m-%d') if student['dob'] else None
#                 formatted_students.append(student)

#             # Wrap the students data in a dictionary
#             response_data = {
#                 'students': formatted_students
#             }
#             return request.make_response(json.dumps(response_data), headers={'Content-Type': 'application/json'})
#         except Exception as e:
#             return request.make_response(json.dumps({'error': str(e)}), headers={'Content-Type': 'application/json'}, status=500)




# class Snippet(http.Controller):
#     @http.route('/get_students_by_class/<int:class_id>', auth='public', type='http', methods=['GET'])
#     def get_students_by_class(self, class_id):
#         try:
#             # Fetch the class record based on the class ID
#             class_record = request.env['fk.class'].sudo().browse(class_id)

#             if not class_record.exists():
#                 return request.make_response(json.dumps({'error': 'Class not found'}), headers={'Content-Type': 'application/json'}, status=404)

#             # Fetch students enrolled in the class, retrieving only id, name, and roll_no
#             students = request.env['fk.student'].sudo().search_read(
#                 [('classes_ids', 'in', [class_record.id])],
#                 ['id', 'name', 'ad_no']
#             )

#             # Wrap only the students data in the response
#             response_data = {
#                 'students': students
#             }

#             return request.make_response(json.dumps(response_data), headers={'Content-Type': 'application/json'})
#         except Exception as e:
#             return request.make_response(json.dumps({'error': str(e)}), headers={'Content-Type': 'application/json'}, status=500)


# class Snippet(http.Controller):
#     @http.route('/get_tt_class/<int:tt_id>', auth='public', type='http', methods=['GET'])
#     def get_tt_class(self, tt_id):
#         try:
#             # Find the timetable record by ID
#             timetable_record = request.env['fk.timetable'].sudo().browse(tt_id)

#             if not timetable_record.exists():
#                 return request.make_response(json.dumps({'error': 'Timetable entry not found'}), headers={'Content-Type': 'application/json'}, status=404)

#             # Fetch the associated class ID and name
#             class_id = timetable_record.classes_id.id if timetable_record.classes_id else None
#             class_name = timetable_record.classes_id.name if timetable_record.classes_id else None

#             if not class_id:
#                 return request.make_response(json.dumps({'error': 'Class not associated with this timetable entry'}), headers={'Content-Type': 'application/json'}, status=404)

#             response_data = {
#                 'timetable_id': tt_id,
#                 'class_id': class_id,
#                 'class_name': class_name
#             }

#             return request.make_response(json.dumps(response_data), headers={'Content-Type': 'application/json'})
#         except Exception as e:
#             return request.make_response(json.dumps({'error': str(e)}), headers={'Content-Type': 'application/json'}, status=500)
